import java.util.Scanner;

public class Leitura {

    private static final Scanner scanner = new Scanner(System.in);

    public static String entDados(String msg){
        System.out.println(msg);
        return scanner.nextLine();
    }
}