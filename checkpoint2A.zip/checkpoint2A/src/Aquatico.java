public class Aquatico extends Animal implements Alimentar {
    private float profundidadeMax;
    private String tipoAgua;

    public Aquatico(String nome, String especie, float peso, int batimentoCardiaco, float temperatura, float profundidadeMax, String tipoAgua) {
        super(nome, especie, peso, batimentoCardiaco, temperatura);
        this.profundidadeMax = profundidadeMax;
        this.tipoAgua = tipoAgua;
    }

    @Override
    public int calcular() {
        // TODO: Retornar a soma do comprimento do nome + comprimento da espécie + profundidade máxima (convertida para int)
    }

    @Override
    public int calcularIdade() {
        // TODO: Retornar temperatura multiplicada por 10 (convertida para int)
    }

    // TODO: Implementar getters e setters para profundidadeMax e tipoAgua

    @Override
    public String toString() {
        //TODO: Implementar para imprimir todos os atributos do animal aquático
    }
}