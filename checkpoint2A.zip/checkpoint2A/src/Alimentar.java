public interface Alimentar {
    public int calcular();
}