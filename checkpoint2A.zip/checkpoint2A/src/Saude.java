public class Saude {
    private int batimentoCardiaco;
    private float temperatura;

    public Saude(int batimentoCardiaco, float temperatura) {
        this.batimentoCardiaco = batimentoCardiaco;
        this.temperatura = temperatura;
    }

    public int getBatimentoCardiaco() {
        return batimentoCardiaco;
    }

    public void setBatimentoCardiaco(int batimentoCardiaco) {
        this.batimentoCardiaco = batimentoCardiaco;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    @Override
    public String toString() {
        return "Saude{" +
                "batimentoCardiaco=" + batimentoCardiaco +
                ", temperatura=" + temperatura +
                '}';
    }
}