public class Terrestre extends Animal implements Alimentar {
    private int qtdPatas;
    private String habitat;

    public Terrestre(String nome, String especie, float peso, int batimentoCardiaco, float temperatura, int qtdPatas, String habitat) {
        super(nome, especie, peso, batimentoCardiaco, temperatura);
        this.qtdPatas = qtdPatas;
        this.habitat = habitat;
    }

    @Override
    public int calcular() {
        // TODO: Retornar a soma de: peso + batimento cardíaco + quantidade de patas (convertido para int)
    }

    @Override
    public int calcularIdade() {
        // TODO: Retornar peso multiplicado por 2 (convertido para int)
    }

    // TODO: Implementar getters e setters para qtdPatas e habitat

    @Override
    public String toString() {
        return super.toString() + "Terrestre{" +
                "qtdPatas=" + qtdPatas +
                ", habitat='" + habitat + '\'' +
                '}';
    }
}