//TODO: Impedir que possam ser instanciados objetos do tipo Animal

public class Animal {
    private String nome;
    private String especie;
    private float peso;
    private Saude saude;

    public Animal(String nome, String especie, float peso, int batimentoCardiaco, float temperatura) {
        this.nome = nome;
        this.especie = especie;
        this.peso = peso;
        this.saude = new Saude(batimentoCardiaco, temperatura);
    }

    // TODO: Implementar todos os getters e setters necessários. 
    //TODO: Impedir que os métodos setters possam ser sobrescritos pelas subclasses que herdarem Animal

    @Override
    public String toString() {
        return "Animal{" +
                "nome='" + nome + '\'' +
                ", especie='" + especie + '\'' +
                ", peso=" + peso +
                ", saude=" + saude +
                '}';
    }

    // TODO: Declarar método abstrato calcularIdade() que retorna int
}