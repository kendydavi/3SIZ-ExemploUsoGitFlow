import java.util.ArrayList;
import java.util.List;

/*****************************************************

 ## Critérios de Avaliação
 - Implementação correta dos TODOs (70%)
 - Funcionamento do sistema completo (20%)
 - Qualidade e organização do código (10%)

 ## Observações
 - Todos os métodos marcados com //TODO devem ser implementados
 - O sistema deve funcionar completamente após a implementação
 - Mantenha a estrutura e padrões do código fornecido

 ********************************************************/

public class Main {
    private static List<Terrestre> listaTerrestre = new ArrayList<Terrestre>();
    private static List<Aquatico> listaAquatico = new ArrayList<Aquatico>();

    // Variáveis globais para armazenar dados temporários
    private static String nome;
    private static String especie;
    private static float peso;
    private static int batimentoCardiaco;
    private static float temperatura;
    private static int qtdPatas;
    private static String habitat;
    private static float profundidadeMax;
    private static String tipoAgua;

    public static void main(String[] args) {
        while(true){
            String opcao = menu();
            switch(opcao) {
                case "1" -> cadastraTerrestre();
                case "2" -> cadastraAquatico();
                case "3" -> imprimeTerrestre();
                case "4" -> imprimeAquatico();
                case "5" -> System.exit(0);
                default -> System.out.println("Digite uma opção válida!");
            }
        }
    }

    private static void cadastraTerrestre() {
        if(listaTerrestre.size()>=2){
            System.out.println("Vagas para animais terrestres lotadas!");
            return;
        }

        cadastra();
        // TODO: Implementar leitura de qtdPatas e habitat com tratamento de exceção
        // Use try-catch para NumberFormatException na qtdPatas
        // habitat pode ser lido diretamente, não repita a pergunta do habitat caso a pessoa tenha informado somente a quantidade de patas incorretamente

        listaTerrestre.add(new Terrestre(nome, especie, peso, batimentoCardiaco, temperatura, qtdPatas, habitat));
        System.out.println("Animal terrestre cadastrado com sucesso!");
    }

    private static void cadastraAquatico() {
        // TODO: Implementar método similar ao cadastraTerrestre
        // Limite: 2 animais aquáticos
        // Ler profundidadeMax (com tratamento de exceção) e tipoAgua
    }

    private static void cadastra(){
        nome = Leitura.entDados("Digite o nome do animal: ");
        especie = Leitura.entDados("Digite a espécie: ");
        boolean invalido = true;
        while(invalido) {
            try {
                peso = Float.parseFloat(Leitura.entDados("Digite o peso: "));
                batimentoCardiaco = Integer.parseInt(Leitura.entDados("Digite o batimento cardíaco: "));
                temperatura = Float.parseFloat(Leitura.entDados("Digite a temperatura corporal: "));
                invalido=false;
            } catch (NumberFormatException e) {
                System.out.println("Essa informação precisa ser um número!");
            }
        }
    }

    // TODO: Implementar método imprimeTerrestre()
    // Verificar se lista está vazia, imprimir mensagem apropriada
    // Caso contrário, imprimir todos os animais terrestres
    // Imprimir para cada animal o resultado de calcular() e calcularIdade()

    // TODO: Implementar método imprimeAquatico()
    // Verificar se lista está vazia, imprimir mensagem apropriada
    // Caso contrário, imprimir todos os animais aquáticos
    // Imprimir para cada animal o resultado de calcular() e calcularIdade()

    private static String menu(){
        System.out.println("\nSistema de Gestão de Animais");
        System.out.println("1. Cadastrar animal terrestre");
        System.out.println("2. Cadastrar animal aquático");
        System.out.println("3. Imprimir todos os animais terrestres");
        System.out.println("4. Imprimir todos os animais aquáticos");
        System.out.println("5. Sair do sistema");

        return Leitura.entDados("Digite a opção desejada: ");
    }
}